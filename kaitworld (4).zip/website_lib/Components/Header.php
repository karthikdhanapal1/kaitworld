<header class="header-area">
    <div class="header-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="navigation">
                        <nav class="navbar navbar-expand-lg">
                            <div class="navbar-brand logo">
                                <a href="index.html">
                                    <img src="website_lib/Assets/images/Brand/Logo.png" alt="" class="d-md-block d-none">
                                    <img src="website_lib/Assets/images/Brand/Logo.png" alt="" class="d-md-none d-block" width="60%">
                                </a>
                            </div>
                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul class="navbar-nav m-auto">
                                    <li class="nav-item active">
                                        <a class="nav-link" href="index.php">Home </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Contest </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Club</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Events </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Gallery</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Blogs</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">About</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Contact</a>
                                    </li>
                                </ul>
                            </div> <!-- navbar collapse -->
                            <div class="navbar-btn d-none d-md-flex">
                                <a class="main-btn main-btn-2 mx-2" href="get-kait-app.php">Download App</a>
                                <a class="main-btn mx-2" href="https://kaitworld.com/public/login">Login</a>
                            </div>
                            <span class="toggle-btn toggle-btn news-canvas_open d-block d-md-none">
                                <i class="fal fa-bars fa-2x"></i>
                            </span>
                        </nav>
                    </div> <!-- navigation -->
                </div>
            </div> <!-- row -->
        </div>
    </div>
</header>