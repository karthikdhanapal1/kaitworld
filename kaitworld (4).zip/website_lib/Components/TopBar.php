 <div class="top-header-area bg-dark">
     <!-- <div class="bg-cover"></div> -->
     <div class="container">
         <div class="row align-items-center">
             <div class="col-lg-6">
                 <div class="topbar-headline">
                     <p>
                         <span><i class="fas fa-bolt"></i> Latest News:</span>
                         <a href="#">Anaikatti trip for club achievers</a>
                     </p>
                 </div>
             </div>
             <div class="col-lg-6">
                 <div class="topbar-social d-flex justify-content-end align-items-center">
                     <div class="news-social">
                         <ul>
                             <li><a href="https://www.facebook.com/kaitcoin" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                             <li><a href="https://twitter.com/Kairaa360" target="_blank"><i class="fab fa-twitter"></i></a></li>
                             <li><a href="https://www.instagram.com/kaitcoin/" target="_blank"><i class="fab fa-instagram"></i></a></li>
                             <li><a href="https://www.linkedin.com/company/kaitcoin/?viewAsMember=true" target="_blank"><i class="fab fa-linkedin"></i></a></li>
                         </ul>
                     </div>
                     <div class="news-subscribe-btn">
                         <a class="btn btn-light " href="#">Subscribe</a>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>