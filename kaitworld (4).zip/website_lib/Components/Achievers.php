<?php

$tripDir = "website_lib/Assets/images/Achievers/Trip/*.jpg";
$tabDir = "website_lib/Assets/images/Achievers/Tab/*.jpeg";
$goldDir = "website_lib/Assets/images/Achievers/Gold/*.jpeg";

$tripImg = glob($tripDir);
$tabImg = glob($tabDir);
$goldImg = glob($goldDir);

?>

<section class="trending-news-box-area pb-40">
    <div class=" container">
        <div class="row">
            <div class=" col-lg-12">
                <div class="trending-news-box">
                    <div class="trending-news-topbar d-block d-md-flex justify-content-between align-items-center">
                        <h3 class="title">Achievers</h3>
                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" id="pills-6-tab" data-bs-toggle="pill" href="#pills-6" role="tab" aria-controls="pills-6" aria-selected="false">4G Tab</a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-2-tab" data-bs-toggle="pill" href="#pills-2" role="tab" aria-controls="pills-2" aria-selected="false">Gold Coin</a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-3-tab" data-bs-toggle="pill" href="#pills-3" role="tab" aria-controls="pills-3" aria-selected="false">Yercaud Trip</a>
                            </li>
                            <!-- <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-4-tab" data-bs-toggle="pill" href="#pills-4" role="tab" aria-controls="pills-4" aria-selected="false">Health</a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-5-tab" data-bs-toggle="pill" href="#pills-5" role="tab" aria-controls="pills-5" aria-selected="false">Nature</a>
                            </li> -->
                        </ul>
                    </div>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane active show" id="pills-6" role="tabpanel" aria-labelledby="pills-6-tab">
                            <div class="row">
                                <div class=" col-lg-12">
                                    <div class="news-slider-2-item">
                                        <?php
                                        foreach ($tabImg as $tab) {
                                            echo '<div class="news-viewed-most"> <div class="thumb rounded-3 mx-2 rounded-3">';
                                            echo "<img alt='' src='$tab'>";
                                            echo '</div></div>';
                                        }; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="pills-2" role="tabpanel" aria-labelledby="pills-2-tab">
                            <div class="row">
                                <div class=" col-lg-12">
                                    <div class="news-slider-2-item">
                                        <?php
                                        foreach ($goldImg as $gold) {
                                            echo '<div class="news-viewed-most"> <div class="thumb rounded-3 mx-2 rounded-3">';
                                            echo "<img alt='' src='$gold'>";
                                            echo '</div></div>';
                                        }; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-3" role="tabpanel" aria-labelledby="pills-3-tab">
                            <div class="row">
                                <div class=" col-lg-12">
                                    <div class="news-slider-2-item">
                                        <?php
                                        foreach ($tripImg as $trip) {
                                            echo '<div class="news-viewed-most"> <div class="thumb rounded-3 mx-2 rounded-3">';
                                            echo "<img alt='' src='$trip'>";
                                            echo '</div></div>';
                                        }; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="tab-pane fade" id="pills-5" role="tabpanel" aria-labelledby="pills-5-tab">
                            <p>pills 5</p>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>