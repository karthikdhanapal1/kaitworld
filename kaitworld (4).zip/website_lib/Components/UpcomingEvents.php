<section class="trending-area">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-9 col-md-12">
                <div class="trending-news-topbar d-block d-md-flex justify-content-between align-items-center">
                    <div class="trending-box">
                        <div class="title">
                            <h3 class="title">Upcoming Events</h3>
                        </div>
                    </div>

                    <!-- <div class="news-tab-btn d-flex justify-content-md-end justify-content-start">
                                <ul class="nav nav-pills " id="pills-tab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link active" id="pills-1-tab" data-bs-toggle="pill"
                                            href="#pills-1" role="tab" aria-controls="pills-1"
                                            aria-selected="true">All</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="pills-2-tab" data-bs-toggle="pill" href="#pills-2"
                                            role="tab" aria-controls="pills-2" aria-selected="false">Travel</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="pills-3-tab" data-bs-toggle="pill" href="#pills-3"
                                            role="tab" aria-controls="pills-3" aria-selected="false">Fashion</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="pills-4-tab" data-bs-toggle="pill" href="#pills-4"
                                            role="tab" aria-controls="pills-4" aria-selected="false">Health</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="pills-5-tab" data-bs-toggle="pill" href="#pills-5"
                                            role="tab" aria-controls="pills-5" aria-selected="false">Nature</a>
                                    </li>
                                </ul>
                            </div> -->
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="trending-news-list">
                            <div class="tab-content mt-50" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-1" role="tabpanel" aria-labelledby="pills-1-tab">
                                    <div class="row">
                                        <div class="col-lg-7 col-md-6">
                                            <div class="trending-box">
                                                <div class="trending-news-item">
                                                    <img src="website_lib/Assets/images/Events/upcoming-1.jpg" alt="">
                                                    <div class="trending-news-overlay">
                                                        <div class="trending-news-meta">
                                                            <div class="meta-categories">
                                                                <a href="#">Event</a>
                                                            </div>
                                                            <div class="meta-date">
                                                                <span><i class="fal fa-calendar-alt"></i> Will
                                                                    announce here!</span>
                                                            </div>
                                                            <h3 class="text-white mt-3">Kairaa Blockchain
                                                                Academy</h3>
                                                            <div class="trending-news-title">
                                                                <h3 class="title"><a href="#">Get Ready for the
                                                                        Launch of Kairaa blockchain Academy,
                                                                        Where Learning
                                                                        Meets Excellence!</a></h3>
                                                            </div>
                                                        </div>
                                                        <div class="news-share">
                                                            <a href="#"><i class="fal fa-share"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-5 col-md-6">
                                            <div class="trending-news-list-item">
                                                <div class="trending-news-list-box">
                                                    <div class="thumb">
                                                        <img src="website_lib/Assets/images/Events/icon-1.png" alt="" width="70%">
                                                    </div>
                                                    <div class="content">
                                                        <div class="trending-news-list-title">
                                                            <h4 class="title"><a href="#">Join Kairaa Blockchain
                                                                    Academy and Empower Yourself with In-Depth
                                                                    Blockchain Education!</a></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="trending-news-list-box">
                                                    <div class="thumb">
                                                        <img src="website_lib/Assets/images/Events/icon-2.png" alt="" width="70%">
                                                    </div>
                                                    <div class="content">
                                                        <div class="trending-news-list-title">
                                                            <h4 class="title"><a href="#">Explore the
                                                                    Cutting-Edge Video Interface Technology for
                                                                    Immersive and Engaging Interactions!</a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="trending-news-list-box">
                                                    <div class="thumb">
                                                        <img src="website_lib/Assets/images/Events/icon-3.png" alt="" width="70%">
                                                    </div>
                                                    <div class="content">
                                                        <div class="trending-news-list-title">
                                                            <h4 class="title"><a href="#">Range of
                                                                    Certifications to Validate Your Skills and
                                                                    Opening Doors to New
                                                                    Opportunities!</a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                <div class="sidebar-categories">
                    <!-- <div class="sidebar-title">
                                <h4 class="title">Categories</h4>
                            </div> -->
                    <div class="categories-list">
                        <div class="item">
                            <a href="#">
                                <span>KAIRAA NFT</span>
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <span>COINCORE</span>
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <span>BUYMOE</span>
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <span>UNIKAA TRADE SIGNAL</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>