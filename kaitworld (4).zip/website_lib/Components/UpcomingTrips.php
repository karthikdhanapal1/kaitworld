<section class="trending-today-area">
    <div class="bg-cover"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="trending-today-topbar">
                    <div class="trending-today-title">
                        <h3 class="title">Upcoming Trips</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="trending-today-item">
                    <div class="trending-news-list-box">
                        <div class="thumb">
                            <img src="website_lib/Assets/images/Trip/trip-1.jpg" alt="">
                        </div>
                        <div class="content">
                            <div class="meta-item">
                                <div class="meta-categories">
                                    <a href="#">Trip</a>
                                </div>
                                <div class="meta-date">
                                    <span><i class="fal fa-calendar-alt"></i> Will Announce</span>
                                </div>
                            </div>
                            <div class="trending-news-list-title">
                                <h4 class="title"><a href="#">Explore the Beauty and Vibrancy of Goa on Our
                                        Upcoming Trip!</a></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="trending-today-item">
                    <div class="trending-news-list-box">
                        <div class="thumb">
                            <img src="website_lib/Assets/images/Trip/trip-3.jpg" alt="">
                        </div>
                        <div class="content">
                            <div class="meta-item">
                                <div class="meta-categories">
                                    <a href="#">Trip</a>
                                </div>
                                <div class="meta-date">
                                    <span><i class="fal fa-calendar-alt"></i> Will Announce</span>
                                </div>
                            </div>
                            <div class="trending-news-list-title">
                                <h4 class="title"><a href="#">Prepare for an Unforgettable Kerala Trip, Immersed
                                        in Nature's Richness!</a></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="trending-today-item">
                    <div class="trending-news-list-box">
                        <div class="thumb">
                            <img src="website_lib/Assets/images/Trip/trip-2.jpg" alt="">
                        </div>
                        <div class="content">
                            <div class="meta-item">
                                <div class="meta-categories">
                                    <a href="#">Trip</a>
                                </div>
                                <div class="meta-date">
                                    <span><i class="fal fa-calendar-alt"></i> Will Announce</span>
                                </div>
                            </div>
                            <div class="trending-news-list-title">
                                <h4 class="title"><a href="#">Exciting Mumbai Adventure, Uncovering the City's
                                        Dynamic Culture.</a></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="trending-today-item">
                    <div class="trending-news-list-box">
                        <div class="thumb">
                            <img src="website_lib/Assets/images/Trip/trip-4.jpg" alt="">
                        </div>
                        <div class="content">
                            <div class="meta-item">
                                <div class="meta-categories">
                                    <a href="#">Trip</a>
                                </div>
                                <div class="meta-date">
                                    <span><i class="fal fa-calendar-alt"></i> Will Announce</span>
                                </div>
                            </div>
                            <div class="trending-news-list-title">
                                <h4 class="title"><a href="#">Discovering the Timeless Beauty of the Taj Mahal
                                        and the Rich Mughal Empire!</a></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>