<section class="video-post-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="video-post-topbar">
                    <div class="video-post-title">
                        <h3 class="title">Video Post</h3>
                    </div>
                </div>
            </div>
            <div class="  col-lg-4">
                <!-- <div class="video-post-tab">
                            <ul class="nav nav-pills justify-content-lg-end justify-content-start" id="pills-tab-2"
                                role="tablist">
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link active" id="pills-21-tab" data-bs-toggle="pill" href="#pills-21"
                                        role="tab" aria-controls="pills-21" aria-selected="true">All</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="pills-22-tab" data-bs-toggle="pill" href="#pills-22"
                                        role="tab" aria-controls="pills-22" aria-selected="false">Travel</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="pills-23-tab" data-bs-toggle="pill" href="#pills-23"
                                        role="tab" aria-controls="pills-23" aria-selected="false">Fashion</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="pills-24-tab" data-bs-toggle="pill" href="#pills-24"
                                        role="tab" aria-controls="pills-24" aria-selected="false">Health</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="pills-25-tab" data-bs-toggle="pill" href="#pills-25"
                                        role="tab" aria-controls="pills-25" aria-selected="false">Nature</a>
                                </li>
                            </ul>
                        </div> -->
            </div>
        </div>
        <div class="tab-content" id="pills-tabContent-2">
            <div class="tab-pane fade show active" id="pills-21" role="tabpanel" aria-labelledby="pills-21-tab">
                <div class=" row">
                    <div class="  col-lg-3 col-md-6 order-lg-1 order-1">
                        <div class="video-post-item">
                            <div class="trending-news-list-box">
                                <div class="thumb">
                                    <img src="website_lib/Assets/images/Videos/video-1.jpg" alt="">
                                    <div class="play">
                                        <a class="video-popup" href="#"><i class="fas fa-play"></i></a>
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="meta-item">
                                        <div class="meta-categories">
                                            <a href="#">Event</a>
                                        </div>
                                        <div class="meta-date">
                                            <span><i class="fal fa-calendar-alt"></i> 5th February 2023</span>
                                        </div>
                                    </div>
                                    <div class="trending-news-list-title">
                                        <h4 class="title"><a href="#">Introducing the Newest Addition to
                                                Tirichi's Network with the Opening of a Branch Office in Your
                                                Area!</a></h4>
                                    </div>
                                </div>
                            </div>
                            <div class="trending-news-list-box">
                                <div class="thumb">
                                    <img src="website_lib/Assets/images/Videos/video-2.jpg" alt="">
                                    <div class="play">
                                        <a class="video-popup" href="#"><i class="fas fa-play"></i></a>
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="meta-item">
                                        <div class="meta-categories">
                                            <a href="#">Meeting</a>
                                        </div>
                                        <div class="meta-date">
                                            <span><i class="fal fa-calendar-alt"></i> 12th April 2023</span>
                                        </div>
                                    </div>
                                    <div class="trending-news-list-title">
                                        <h4 class="title"><a href="#">Highlights from the Tiruvallur Leaders'
                                                Meet as Visionaries Collaborate for the Betterment of the
                                                Region!</a></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="  col-lg-6 order-lg-2 order-3">
                        <div class="video-post-item">
                            <div class="trending-news-list-box main-item">
                                <div class="thumb">
                                    <img src="website_lib/Assets/images/Videos/video-3.jpg" alt="">
                                    <div class="play">
                                        <a class="video-popup" href="#"><i class="fas fa-play"></i></a>
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="meta-item">
                                        <div class="meta-categories">
                                            <a href="#">Event</a>
                                        </div>
                                        <div class="meta-date">
                                            <span><i class="fal fa-calendar-alt"></i> 11th December 2023</span>
                                        </div>
                                    </div>
                                    <div class="trending-news-list-title">
                                        <h4 class="title"><a href="#">Celebrating the Successful Launch of a
                                                Groundbreaking Cryptocurrency Exchange, Empowering Users with
                                                Seamless Trading
                                                and Financial Opportunities!</a></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="  col-lg-3 col-md-6 order-lg-3 order-2">
                        <div class="video-post-item">
                            <div class="trending-news-list-box">
                                <div class="thumb">
                                    <img src="website_lib/Assets/images/Videos/video-4.jpg" alt="">
                                    <div class="play">
                                        <a class="video-popup" href="#"><i class="fas fa-play"></i></a>
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="meta-item">
                                        <div class="meta-categories">
                                            <a href="#">Meeting</a>
                                        </div>
                                        <div class="meta-date">
                                            <span><i class="fal fa-calendar-alt"></i> 08th February 2023</span>
                                        </div>
                                    </div>
                                    <div class="trending-news-list-title">
                                        <h4 class="title"><a href="#">Solingur Crypto Exchange Awareness
                                                Meeting,
                                                Spreading Knowledge in
                                                Cryptocurrency!</a></h4>
                                    </div>
                                </div>
                            </div>
                            <div class="trending-news-list-box">
                                <div class="thumb">
                                    <img src="website_lib/Assets/images/Videos/video-5.jpg" alt="">
                                    <div class="play">
                                        <a class="video-popup" href="#"><i class="fas fa-play"></i></a>
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="meta-item">
                                        <div class="meta-categories">
                                            <a href="#">Meeting</a>
                                        </div>
                                        <div class="meta-date">
                                            <span><i class="fal fa-calendar-alt"></i> 09th February 2023</span>
                                        </div>
                                    </div>
                                    <div class="trending-news-list-title">
                                        <h4 class="title"><a href="#">Blockchain Awareness Meeting, Fueling
                                                Knowledge and Inspiring Adoption of Blockchain.</a></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>