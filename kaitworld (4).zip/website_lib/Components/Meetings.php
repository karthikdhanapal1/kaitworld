<section class="featured-area">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-4 col-md-6">
                <div class="featured-slider mt-30">
                    <div class="featured-title">
                        <h3 class="title">Meetings</h3>
                    </div>
                    <div class="featured-slider-item">
                        <div class="trending-news-list-box">
                            <div class="thumb">
                                <img src="website_lib/Assets/images/Meetings/meeting-1.jpg" alt="">
                            </div>
                            <div class="content">
                                <div class="meta-item">
                                    <div class="meta-categories">
                                        <a href="#">Meetings</a>
                                    </div>
                                    <div class="meta-date">
                                        <span><i class="fal fa-calendar-alt"></i> 08th February 2023</span>
                                    </div>
                                </div>
                                <div class="trending-news-list-title">
                                    <h4 class="title"><a href="#">Sholingur Blockchain and Crypto Awareness
                                            Meeting proved to be a remarkable event fostering a greater
                                            understanding.
                                        </a></h4>
                                </div>
                            </div>
                        </div>
                        <div class="trending-news-list-box">
                            <div class="thumb">
                                <img src="website_lib/Assets/images/Meetings/meeting-2.jpg" alt="">
                            </div>
                            <div class="content">
                                <div class="meta-item">
                                    <div class="meta-categories">
                                        <a href="#">Meetings</a>
                                    </div>
                                    <div class="meta-date">
                                        <span><i class="fal fa-calendar-alt"></i> 5th February 2020</span>
                                    </div>
                                </div>
                                <div class="trending-news-list-title">
                                    <h4 class="title"><a href="#">Tiruchi Blockchain and Crypto Awareness
                                            Meeting, attendees delved into the fundamentals of blockchain.</a>
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-md-6">
                <div class="trending-news-item mb-30">
                    <img src="website_lib/Assets/images/Meetings/meeting-3.jpg" alt="">
                    <div class="trending-news-overlay">
                        <div class="trending-news-meta">
                            <div class="meta-categories">
                                <a href="#">Meetings</a>
                            </div>
                            <div class="meta-date">
                                <span><i class="fal fa-calendar-alt"></i> 9th February 2023</span>
                            </div>
                            <div class="trending-news-title">
                                <h3 class="title"><a href="#">The Ambur Blockchain and Crypto Awareness Meeting
                                        proved to be a significant event.</a></h3>
                            </div>
                        </div>
                        <div class="news-share">
                            <a href="#"><i class="fal fa-share"></i></a>
                        </div>
                    </div>
                </div>
                <div class="trending-news-item mb-30">
                    <img src="website_lib/Assets/images/Meetings/meeting-4.jpg" alt="">
                    <div class="trending-news-overlay">
                        <div class="trending-news-meta">
                            <div class="meta-categories">
                                <a href="#">Meetings</a>
                            </div>
                            <div class="meta-date">
                                <span><i class="fal fa-calendar-alt"></i> 25th March 2020</span>
                            </div>
                            <div class="trending-news-title">
                                <h3 class="title"><a href="#">The Vellore Business and Leaders Meet brought
                                        together entrepreneurs from various
                                        industries.</a></h3>
                            </div>
                        </div>
                        <div class="news-share">
                            <a href="#"><i class="fal fa-share"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="sidebar-social">
                    <div class="sidebar-title">
                        <h4 class="title">Meeting Attendance</h4>
                    </div>
                    <div class="social-list">
                        <div class="list">
                            <a href="#">
                                <span><em class="fas fa-male mx-2"></em> Total Mens</span>
                                <span>1600+</span>
                            </a>
                            <a href="#">
                                <span><em class="fas fa-female mx-2"></em> Total Womens</span>
                                <span>1400+</span>
                            </a>
                            <a href="#">
                                <span><em class="fas fa-users mx-2"></em> Total Participants</span>
                                <span>3000+</span>
                            </a>
                            <a href="#">
                                <span><em class="fas fa-user mx-2"></em> KAIT Users</span>
                                <span>600+</span>
                            </a>
                            <a href="#">
                                <span><em class="fas fa-user-plus mx-2"></em> New Users</span>
                                <span>2000+</span>
                            </a>
                        </div>
                    </div>
                    <div class="sidebar-add mt-20">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>