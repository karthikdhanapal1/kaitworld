    <div class="footer-copyright-area">
        <div class=" container">
            <div class="row align-items-center">
                <div class=" col-lg-4">
                    <div class="copyright-text">
                        <p>@<span>www.kaitworld.com</span> - 2023</p>
                    </div>
                </div>
                <div class=" col-lg-8">
                    <div class="copyright-menu float-lg-end float-none">
                        <ul>
                            <li><a href="#">Terms of Use</a></li>
                            <li><a href="/privacy-policy">Privacy Policy</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>