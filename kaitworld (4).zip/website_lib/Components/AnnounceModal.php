<div class="modal hide fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <img src="website_lib/Assets/images/anaikatti.jpg" class=" rounded-bottom-3" />
            </div>
        </div>
    </div>
</div>