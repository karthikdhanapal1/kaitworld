<section class="news-slider-2-area pt-50">
    <div class=" container-fluid p-0">
        <div class="row">
            <div class=" col-lg-12">
                <div class="news-slider-2-item">
                    <div class="news-viewed-most">
                        <div class="thumb">
                            <img src="website_lib/Assets/images/Slider/slider-4.jpg" alt="">
                        </div>
                        <div class="content">
                            <div class="meta-item">
                                <div class="meta-categories">
                                    <a href="#">Event</a>
                                </div>
                                <div class="meta-date">
                                    <span><i class="fal fa-calendar-alt"></i> 18th June 2023</span>
                                </div>
                            </div>
                            <h4 class="title"><a href="#">Launching the vPay Payment App for Seamless
                                    Transactions and Financial Freedom!</a></h4>
                        </div>
                    </div>
                    <div class="news-viewed-most">
                        <div class="thumb">
                            <img src="website_lib/Assets/images/Slider/slider-5.jpg" alt="">
                        </div>
                        <div class="content">
                            <div class="meta-item">
                                <div class="meta-categories">
                                    <a href="#">Event</a>
                                </div>
                                <div class="meta-date">
                                    <span><i class="fal fa-calendar-alt"></i> 18th June 2023</span>
                                </div>
                            </div>
                            <h4 class="title"><a href="#">Unveiling Our Revolutionary Blockchain Network:
                                    Empowering You with Decentralized Possibilities!</a></h4>
                        </div>
                    </div>
                    <div class="news-viewed-most">
                        <div class="thumb">
                            <img src="website_lib/Assets/images/Slider/slider-1.jpg" alt="">
                        </div>
                        <div class="content">
                            <div class="meta-item">
                                <div class="meta-categories">
                                    <a href="#">Contest</a>
                                </div>
                                <div class="meta-date">
                                    <span><i class="fal fa-calendar-alt"></i> 18th June 2023</span>
                                </div>
                            </div>
                            <h4 class="title"><a href="#">Kait Stacking Rewards: Unlock Your Achievements and
                                    Claim Your 4G Tablets!</a></h4>
                        </div>
                    </div>
                    <div class="news-viewed-most">
                        <div class="thumb">
                            <img src="website_lib/Assets/images/Slider/slider-3.jpg" alt="">
                        </div>
                        <div class="content">
                            <div class="meta-item">
                                <div class="meta-categories">
                                    <a href="#">Event</a>
                                </div>
                                <div class="meta-date">
                                    <span><i class="fal fa-calendar-alt"></i> 18th June 2023</span>
                                </div>
                            </div>
                            <h4 class="title"><a href="#">Experience the Future of Stacking: Launching the Kait
                                    Coin Stacking App for Effortless Coin Management!</a></h4>
                        </div>
                    </div>
                    <div class="news-viewed-most">
                        <div class="thumb">
                            <img src="website_lib/Assets/images/Slider/slider-2.jpg" alt="">
                        </div>
                        <div class="content">
                            <div class="meta-item">
                                <div class="meta-categories">
                                    <a href="#">Club</a>
                                </div>
                                <div class="meta-date">
                                    <span><i class="fal fa-calendar-alt"></i> 18th June 2023</span>
                                </div>
                            </div>
                            <h4 class="title"><a href="#">Attention Bronze Club Achievers: Unlock the Prestige
                                    of Gold with Exclusive Gold Coins!</a></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>