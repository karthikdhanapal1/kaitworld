<!doctype html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!--====== Title ======-->
        <title>Kaitworld | Community for kait users</title>

        <!--====== Favicon Icon ======-->
        <link rel="shortcut icon" href="website_lib/Assets/images/Brand/Favicon.png" type="image/png">

        <!--====== Bootstrap css ======-->
        <link rel="stylesheet" href="website_lib/Assets/css/bootstrap.min.css">

        <!--====== Fontawesome css ======-->
        <link rel="stylesheet" href="website_lib/Assets/css/font-awesome.min.css">

        <!--====== nice select css ======-->
        <link rel="stylesheet" href="website_lib/Assets/css/nice-select.css">

        <!--====== Magnific Popup css ======-->
        <link rel="stylesheet" href="website_lib/Assets/css/magnific-popup.css">

        <!--====== Slick css ======-->
        <link rel="stylesheet" href="website_lib/Assets/css/slick.css">

        <!--====== Default css ======-->
        <link rel="stylesheet" href="website_lib/Assets/css/default.css">

        <!--====== Style css ======-->
        <link rel="stylesheet" href="website_lib/Assets/css/style.css">


    </head>

    <body>


        <!--====== OFFCANVAS MENU PART START ======-->

        <div class="news-off_canvars_overlay"></div>
        <div class="news-offcanvas_menu w-25">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="news-offcanvas_menu_wrapper">
                            <div class="news-canvas_close">
                                <a href="javascript:void(0)"><i class="fal fa-times"></i></a>
                            </div>
                            <div id="menu" class="text-left ">
                                <ul class="navbar-nav m-auto display-6 ps-4">
                                    <li class="nav-item active">
                                        <a class="nav-link" href="index.php">Home </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Contest </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Club</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Events </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Gallery</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Blogs</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">About</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Contact</a>
                                    </li>
                                </ul>
                            </div>
                            <a class="main-btn mt-3 ms-4" href="https://kaitworld.com/public/login">Login</a>
                            <a class="main-btn mt-3 ms-4" href="https://kaitworld.com/get-kait-app.php">Get App</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php require 'website_lib/Components/TopBar.php' ?>
        <?php require 'website_lib/Components/Header.php' ?>

        <!-- <?php require 'website_lib/Components/NewsSlider.php' ?> -->

        <?php require 'website_lib/Components/UpcomingEvents.php' ?>

        <?php require 'website_lib/Components/Achievers.php' ?>

        <?php require 'website_lib/Components/Meetings.php' ?>

        <?php require 'website_lib/Components/VideoPost.php' ?>

        <?php require 'website_lib/Components/UpcomingTrips.php' ?>


        <section class="top-news-2-area pt-40 mt-70">
            <div class=" container">
                <div class="row">

                    <div class=" col-lg-4">
                        <div class="top-news-2-item">
                            <div class="trending-news-item mb-30"></div>
                        </div>
                    </div>
                    <div class=" col-lg-4">
                        <div class="top-news-2-item top-news-2-1-item" style="margin-left: 0 !important">
                            <div class="trending-news-item mb-30"
                                style="margin-left: 0 !important; margin-right:60px !important;">
                            </div>
                            <div class="trending-news-item item-2 mb-30"
                                style="margin-left: 0 !important; margin-right:60px !important;">
                            </div>
                        </div>
                    </div>
                    <div class=" col-lg-4">
                        <div class="top-news-3-item">
                            <div class="trending-news-item mb-30"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div class="contact-us-area mt-100">
            <div class=" container-fluid">
                <div class="row">
                    <div class=" col-lg-8">
                        <div class="contact-us-box">
                            <form action="#">
                                <div class="contact-title">
                                    <h4 class="title">Get in touch & let us know</h4>
                                </div>
                                <div class="row">
                                    <div class=" col-lg-6">
                                        <div class="input-box">
                                            <input type="text" placeholder="Enter full name">
                                            <i class="fal fa-user"></i>
                                        </div>
                                    </div>
                                    <div class=" col-lg-6">
                                        <div class="input-box">
                                            <input type="email" placeholder="Enter address">
                                            <i class="fal fa-envelope"></i>
                                        </div>
                                    </div>
                                    <div class=" col-lg-12">
                                        <div class="input-box">
                                            <textarea name="#" id="#" cols="30" rows="10"
                                                placeholder="Enter message"></textarea>
                                            <i class="fal fa-pencil"></i>
                                        </div>
                                    </div>
                                </div>
                                <button class="main-btn w-100">Submit Request</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <img src="website_lib/Assets/images/poster.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>

        <?php require 'website_lib/Components/AnnounceModal.php' ?>

        <?php require 'website_lib/Components/Footer.php' ?>

        <div class="back-to-top" onclick="window.scrollTo(0)">
            <p>BACK TO TOP <i class="fal fa-long-arrow-right"></i></p>
        </div>

        <script src="website_lib/Assets/js/vendor/modernizr-3.6.0.min.js"></script>
        <script src="website_lib/Assets/js/vendor/jquery-1.12.4.min.js"></script>
        <script src="website_lib/Assets/js/bootstrap.min.js"></script>
        <script src="website_lib/Assets/js/popper.min.js"></script>
        <script src="website_lib/Assets/js/slick.min.js"></script>
        <script src="website_lib/Assets/js/jquery.nice-select.min.js"></script>
        <script src="website_lib/Assets/js/isotope.pkgd.min.js"></script>
        <script src="website_lib/Assets/js/imagesloaded.pkgd.min.js"></script>
        <script src="website_lib/Assets/js/jquery.magnific-popup.min.js"></script>
        <script src="website_lib/Assets/js/main.js"></script>
        <script type="text/javascript">
        $(window).on('load', function() {
            // $('#myModal').modal('show');
        });
        </script>
    </body>

</html>