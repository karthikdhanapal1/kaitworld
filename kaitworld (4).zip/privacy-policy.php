<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!--====== Title ======-->
<title>Kaitworld | Privacy Policy</title>

<!--====== Favicon Icon ======-->
<link rel="shortcut icon" href="website_lib/Assets/images/Brand/Favicon.png" type="image/png">

<!--====== Bootstrap css ======-->
<link rel="stylesheet" href="website_lib/Assets/css/bootstrap.min.css">

<!--====== Fontawesome css ======-->
<link rel="stylesheet" href="website_lib/Assets/css/font-awesome.min.css">

<!--====== nice select css ======-->
<link rel="stylesheet" href="website_lib/Assets/css/nice-select.css">

<!--====== Magnific Popup css ======-->
<link rel="stylesheet" href="website_lib/Assets/css/magnific-popup.css">

<!--====== Slick css ======-->
<link rel="stylesheet" href="website_lib/Assets/css/slick.css">

<!--====== Default css ======-->
<link rel="stylesheet" href="website_lib/Assets/css/default.css">

<!--====== Style css ======-->
<link rel="stylesheet" href="website_lib/Assets/css/style.css">


</head>
<body class="d-flex justify-content-center">
    <section class="w-75 pt-50">
    <h1>Privacy and Policy</h1><br>
<p><div> &nbsp; &nbsp;This privacy policy was developed by Kaitworld, a privacy-based ecosystem, to highlight our dedication to your privacy.This privacy statement ("Privacy Policy") will inform you about &nbsp;&nbsp;&nbsp;The collection,processing, and use of personal data when you visit our websites.It also explains your options for using, accessing and correcting your personal information,as well as &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;Your Rights in deciding what we do with the information we collect or keep about you. Our objective is to empower you by providing you with straightforward and clear information<br> &nbsp; &nbsp; That will allow you to make informed decisions regarding our products and services.</Div><br>

<li>We’re committed to safeguarding and respecting your personal information. Your data is solely used to provide and improve the Service.</li> <br>

<li> We reserve the right to modify this Policy at any time, so please revisit this page from time to time to confirm that you are satisfied with any changes. By using our website, you agree &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To be governed by this Policy.</li> 
</p><br>
<p><h1>1. Information Collection And Use</h2> <br> <Div><li> In order to deliver and enhance our Service to you, we gather a variety of information from you.</Div></li></p><br>

<p> <h1>2. Types of Data Collected </h1><br>

<p> <em>2.1. Personal Data </em><br>

<li>We may ask you to provide us with personally identifying information that can be used to contact or identify you while using our Service ("Personal Data"). Personal identifiable  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;information may include, but is not limited to, the following:</Div></li> 

<li>Email address </li>

<li>First name and last name </li>

<li>Address, State, Province, ZIP/Postal code, City </li>

<li>Cookies and Usage Data </li>

<li>Usage Data </li>
<li>We may also collect information about how you access and use the Service ("Usage Data"). Usage Data may include your computer's Internet Protocol address (e.g IP address), Browser type, browser version, the pages of our Service that you view, the time and date of your visit, the time spent on those pages, unique device identifiers, and other diagnostic data.</li></p><br>
<p><em>2.2. Tracking & Cookies Data</em><br>

<li>We use cookies and other tracking technologies to monitor and record activities on our Service.</li>

<li>Cookies are little data files that may carry an anonymous unique identification. Cookies are little text files that are transmitted to your browser by a website and stored on your &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Device. Beacons, tags, and scripts are other tracking technologies that are used to collect and track information as well as to develop and analyze our Service.</li> 

<li>You can set your browser to refuse all cookies or to notify you when one is transmitted. However, if you do not accept cookies, you may be unable to utilize certain features of <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;our Service.</li></p> <br>
<p><h1>3. Use of Data </h1><br>

<li>kaitworld.com uses the collected data for various purposes:</li>
 
<li>To provide and maintain the Service </li>

<li>To notify you about changes to our Service </li>

<li>To allow you to participate in interactive features of our Service when you choose to do so </li>

<li>To provide customer care and support </li>

<li>To provide analysis or valuable information so that we can improve the Service </li>

<li>To monitor the usage of the Service </li>

<li>To detect, prevent and address technical issues</li> </p><br>

<p><h1>4. Transfer Of Data</h1><br>

<li>Your information, including Personal Data, may be transferred to and stored on computers located outside of your state, province, nation, or other governmental jurisdiction where &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Data protection regulations differ from those in your jurisdiction.</li> 
<li>Your agreement to that transfer is represented by your approval to this Privacy Policy, followed by your submission of such information.</li> 

<li>kaitworld.com will take all reasonable steps to ensure that your data is treated securely and in 
in accordance with this Privacy Policy, and no transfer of your Personal Data to an &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Organization or country will take place unless adequate controls are in place, including the security of your data and other personal information.</li></p><br> 

<p><h1>5. Disclosure Of Data</h1><br>

<em>5.1. Legal Requirements</em><br>

<li>kaitworld.com may disclose your Personal Data in the good faith belief that such action is necessary to: </li>

<li>To comply with a legal obligation </li>

<li>To protect and defend the rights or property of kaitworld.com </li>

<li>To prevent or investigate possible wrongdoing in connection with the Service </li>

<li>To protect the personal safety of users of the Service or the public </li><br>

<p><h1>6. Security Of Data</h1><br>
&nbsp;<li>We care about the security of your data, but keep in mind that no form of Internet transmission or computer storage is 100% safe. While we endeavor to use commercially </div> <div>&nbsp; &nbsp; &nbsp; &nbsp; acceptable procedures to protect your Personal Data, we cannot guarantee its total security.</div></li></p><br> 

<p><h1>7. Service Providers</h1><br>

<li>We may hire third-party companies and individuals to facilitate our Service ("Service Providers"), to deliver the Service on our behalf, to undertake Service-related functions, or to &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Assist us in analyzing how our Service is used.</li>

<li>These third parties have access to your Personal Data only to perform these duties on our behalf and are not permitted to disclose or use it for any other reason.</li></p><br> 

<p><h1>8. Analytics</h1><br>

We may utilize third-party Service Providers to monitor and analyze how our Service is used..</p><br>

<p><h1>9. General Data Protection Regulation (GDPR)</h1><br>

<li>We are the Data Controller for your personal information. Please read the GDPR guide if you want to understand more about GDPR and your rights under GDPR.</li> 

<li>The legal basis for collecting and using personal information specified in this Privacy Policy is determined by the Personal Information we collect and the precise context in which the &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Information is collected:</li> 

<li>kaitworld.com needs to perform a contract with you;</li> 

<li>You have given kaitworld.com permission to do so; </li>

<li>Processing your personal information is in kaitworld.com legitimate interests;</li> 


<li>kaitworld.com will only keep your personal information for as long as it is required for the purposes outlined in this Privacy Policy. We will keep and use your information just as long &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;As it is required to comply with our legal requirements, resolve disputes, and enforce our rules.In certain circumstances, you have the following data protection rights: 
The right to &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Access, update or to delete the information we have on you.</li> 

<li>The right of rectification. </li> 

<li>The right to object. </li> 

<li>The right of restriction. </li> 

<li>The right to data portability </li> 

<li>The right to withdraw consent </li> </p><br>

<p><h1>10. Log Files</h1><br>
<li>kaitworld.com uses log files in accordance with industry standards. When people visit websites, these files keep track of who they are. This is something that all hosting firms perform, and it is part of the analytics for hosting services. Internet Protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit sites, and perhaps the number of clicks are among the data gathered by log files. These aren't linked to any personally identifiable information. The information is used for trend analysis, site administration, tracking user movement on the site, and demographic data collection.</li></p><br> 

<p><h1>11. Links To Other Sites</h1><br>

<li>Our Service may contain connections to websites that are not operated by us. If you click on a third-party link, you will be sent to that third-party's website. We strongly suggest you &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Read the Privacy Policies of every website you visit.</li> 

<li>We have no control over, and accept no responsibility for, the content, privacy policies, or practices of any third-party sites or services.</li></p><br>

<p><Div><h1>12. Children’s Privacy</h1></Div><br>

<li>Our Service does not address anyone under the age of 14 ("Children"). We encourage parents and guardians to observe, participate in, monitor, and manage their children's online <br> &nbsp; &nbsp; &nbsp; &nbsp; Behavior.</li> 

<li>We do not intentionally collect personally identifying information from anybody under the age of 18. If you are a parent or guardian and are aware that your child has provided us<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; With Personal Data, please contact us. If we discover that we have obtained Personal Data from children without parental authorization, we take steps to erase that information <br>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From our servers.</li></p><br>

<p><h1>13. Changes To This Privacy Policy</h1> <br>

 <Div> <li> We reserve the right to change our Privacy Policy at any moment. Any changes will be
communicated to you by posting the revised Privacy Policy on this page.</li>
</li> &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prior to the modification becoming effective, we will notify you through email and/or a
conspicuous notice on our Service, and we will revise the "effective date" at the top of this &nbsp; &nbsp;
<div>&nbsp; &nbsp; &nbsp; &nbsp;Privacy Policy.</div></li>
<li>It is recommended that you examine this Privacy Policy on a regular basis for any updates.
When changes to this Privacy Policy are posted on this page, they become effective.</li></Div></p><br>

<p><h1>14. Contact Us</h1><br>

 <Div>
&nbsp;&nbsp; Please contact us if you have any queries regarding this Privacy Policy:<br>&nbsp; &nbsp;By email: support@kaitworld.com </Div></p><br>
    </section>
</body>
</html>